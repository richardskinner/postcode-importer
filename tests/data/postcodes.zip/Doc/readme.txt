Notes on the Supply of Ordnance Survey Digital Data
---------------------------------------------------

   Directory Structure
   -------------------

   The directory structure is shown below:

			  root
			   |
		      ------------
		     |            |
		   data          doc 


   The DATA directory contains the data files.

   The DOC directory will contain the following ASCII text files:
	  o licence.txt - important licence information.
	  o readme.txt - this file.



